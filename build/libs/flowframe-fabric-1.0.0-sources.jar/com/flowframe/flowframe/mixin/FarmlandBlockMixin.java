package com.flowframe.flowframe.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2344;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Prevents crop trampling outright by cancelling the farmland-to-dirt
 * conversion at its source. DO_MOB_GRIEFING being forced off only stops mobs
 * (vanilla's own trample check is "entity instanceof Player || mobGriefing"),
 * so players could still trample crops even with that gamerule off — this
 * mixin covers both, unconditionally.
 */
@Mixin(class_2344.class)
public class FarmlandBlockMixin {

    @Inject(method = "setToDirt", at = @At("HEAD"), cancellable = true)
    private static void flowframe$preventTrample(class_1297 entity, class_2680 state, class_1937 world, class_2338 pos, CallbackInfo ci) {
        ci.cancel();
    }
}
