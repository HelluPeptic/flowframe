package com.flowframe.flowframe;

import java.nio.file.Path;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.group.Group;
import net.luckperms.api.model.user.User;
import net.luckperms.api.node.NodeType;
import net.luckperms.api.node.types.MetaNode;
import net.minecraft.class_12090;
import net.minecraft.class_12099;
import net.minecraft.class_12279;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2752;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3468;
import net.minecraft.class_3730;

public class FlowframeFabricMod implements ModInitializer {
    public static final String MOD_ID = "flowframe";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // Whether the LuckPerms mod is present on this server. Checked once at
    // startup so we never touch the LuckPerms API classes if it isn't loaded.
    private static final boolean LUCKPERMS_LOADED = FabricLoader.getInstance().isModLoaded("luckperms");

    private final DataManager dataManager;
    // ServerPlayerEntity's own "server" field is private, with no public getter on the
    // entity itself — stashing the instance here once at startup (well before any player
    // can trigger a callback that needs it) avoids relying on entity-side accessors at all.
    private volatile net.minecraft.server.MinecraftServer serverInstance;
    private final Set<UUID> headRiders = new java.util.HashSet<>();
    // Rider UUID -> target UUID. Needed so that whenever a ride ends, for ANY reason
    // (our own sneak handling, vanilla's own built-in dismount-on-sneak beating us to
    // it, the rider disconnecting, etc.), we still know who to notify.
    private final Map<UUID, UUID> headRiderTargets = new java.util.HashMap<>();
    private int tickCounter;

    // Phantoms are relocated to The End: DO_INSOMNIA is forced off (below) so vanilla's
    // own PhantomSpawner never fires anywhere, and this replicates just its "haven't
    // slept in 3 days" condition against players standing in The End instead.
    private static final int PHANTOM_CHECK_PERIOD_TICKS = 200; // every 10s
    private static final int PHANTOM_INSOMNIA_TICKS = 72000; // 3 in-game days, matches vanilla
    private static final int PHANTOM_SPAWN_CHANCE_ONE_IN = 6; // ~once/minute per eligible player
    private static final int PHANTOM_HORIZONTAL_SPREAD = 20;
    private static final int PHANTOM_MIN_HEIGHT_ABOVE = 16;
    private static final int PHANTOM_HEIGHT_ABOVE_RANGE = 14;
    private final Random phantomRandom = new Random();
    private int phantomTickCounter;

    // Exposed so EndPortalBlockMixin (which has no other way to reach mod state) can
    // check isEndPortalEnabled() without needing a full dependency-injection setup.
    private static FlowframeFabricMod instance;

    public static FlowframeFabricMod getInstance() {
        return instance;
    }

    public FlowframeFabricMod() {
        instance = this;
        Path configDir = FabricLoader.getInstance().getConfigDir().resolve(MOD_ID);
        this.dataManager = new DataManager(configDir.resolve("flowframe_data.json"));
    }

    @Override
    public void onInitialize() {
        registerCommands();
        registerEvents();
        LOGGER.info("Flowframe Fabric mod initialized");
    }

    private void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(
                class_2170.method_9247("keepinv")
                    .executes(context -> {
                        class_2168 source = context.getSource();
                        class_3222 player = source.method_44023();
                        if (player == null) {
                            source.method_9226(() -> class_2561.method_43470("This command can only be used by players."), false);
                            return 1;
                        }
                        boolean nowOptedOut = dataManager.toggle(player.method_5667());
                        player.method_7353(class_2561.method_43470("Keep Inventory: " + (nowOptedOut ? "OFF" : "ON")).method_27692(nowOptedOut ? class_124.field_1061 : class_124.field_1060), false);
                        return 1;
                    })
            );

            dispatcher.register(
                class_2170.method_9247("endtoggle")
                    .requires(class_2170.method_71774(new class_12090.class_12092(class_12099.field_63210)))
                    .executes(context -> {
                        boolean nowEnabled = !dataManager.isEndPortalEnabled();
                        dataManager.setEndPortalEnabled(nowEnabled);
                        class_2561 state = nowEnabled ? class_2561.method_43470("ENABLED").method_27692(class_124.field_1060) : class_2561.method_43470("DISABLED").method_27692(class_124.field_1061);
                        context.getSource().method_9211().method_3760().method_43514(class_2561.method_43470("End portals are now ").method_10852(state).method_10852(class_2561.method_43470(".")), false);
                        return 1;
                    })
            );
        });
    }

    private void registerEvents() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_3222 player = handler.field_14140;
            if (!dataManager.hasSeenPlayer(player.method_5667())) {
                dataManager.markSeenPlayer(player.method_5667());
                server.method_3760().method_43514(class_2561.method_43470(player.method_5477().getString() + " joined the server for the first time! Welcome them!").method_27692(class_124.field_1065), false);
            }
        });

        ServerMessageEvents.ALLOW_CHAT_MESSAGE.register((message, sender, params) -> {
            class_124 nameColor = resolveGroupColor(sender);
            class_2561 formatted = class_2561.method_43470(sender.method_5477().getString())
                .method_27692(nameColor)
                .method_10852(class_2561.method_43470(" » ").method_27692(class_124.field_1063))
                .method_10852(class_2561.method_43470(message.method_44862()).method_27692(class_124.field_1068));
            serverInstance.method_3760().method_43514(formatted, false);

            // Returning false below skips vanilla's own "<Name> message" broadcast (so we
            // don't get a duplicate, differently-formatted line) — but per PlayerManagerMixin
            // in fabric-message-api, that also skips the CHAT_MESSAGE notify event entirely,
            // which is what bridge mods like Discord4Fabric listen on to relay chat elsewhere.
            // Fire it ourselves so those mods still see the message even though we've taken
            // over the actual in-game broadcast.
            ServerMessageEvents.CHAT_MESSAGE.invoker().onChatMessage(message, sender, params);
            return false;
        });

        // Safety net only now: EndPortalBlockMixin blocks portal entry outright, so
        // under normal circumstances a player should never actually arrive in The End
        // while it's disabled. This stays in place to catch edge cases (commands,
        // other mods/plugins, end gateways, etc.) that don't go through the block.
        ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD.register((player, origin, destination) -> {
            if (!dataManager.isEndPortalEnabled() && destination.method_27983() == class_1937.field_25181) {
                teleportPlayerOutOfTheEnd(player);
            }
        });

        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.method_8608()) {
                return class_1269.field_5811;
            }
            if (!(player instanceof class_3222 rider)) {
                return class_1269.field_5811;
            }
            if (hand != class_1268.field_5808) {
                return class_1269.field_5811;
            }
            if (!rider.method_5998(hand).method_7960() || !rider.method_6079().method_7960()) {
                return class_1269.field_5811;
            }
            if (!(entity instanceof class_3222 clicked) || clicked.method_5667().equals(rider.method_5667())) {
                return class_1269.field_5811;
            }
            if (rider.method_7325() || clicked.method_7325()) {
                return class_1269.field_5811;
            }
            if (rider.method_5765()) {
                return class_1269.field_5811;
            }

            // Right-clicking ANY player in an existing stack attaches the new rider to
            // the current top of that stack, not just to whoever was clicked directly —
            // otherwise you have to click the exact, often visually obscured, top player.
            UUID topId = clicked.method_5667();
            UUID nextRiderId = findRiderOf(topId);
            while (nextRiderId != null) {
                if (nextRiderId.equals(rider.method_5667())) {
                    // Rider is already somewhere in this stack.
                    return class_1269.field_5811;
                }
                topId = nextRiderId;
                nextRiderId = findRiderOf(topId);
            }
            class_3222 top = topId.equals(clicked.method_5667()) ? clicked : serverInstance.method_3760().method_14602(topId);
            if (top == null || top.method_5782()) {
                return class_1269.field_5811;
            }

            if (rider.method_5873(top, true, true)) {
                headRiders.add(rider.method_5667());
                headRiderTargets.put(rider.method_5667(), top.method_5667());
                // The vehicle's own client never receives the normal entity-tracking
                // broadcast about its own passengers (a player doesn't "track" itself),
                // so without this the target never learns they have a rider and keeps
                // rendering them at the old spot. Send it directly to their connection.
                top.field_13987.method_14364(new class_2752(top));
                return class_1269.field_5812;
            }
            return class_1269.field_5811;
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
            if (entity instanceof class_3222 player) {
                if (dataManager.isOptedOut(player.method_5667())) {
                    dropInventory(player);
                }
                if (isSelfProjectileKill(player, damageSource)) {
                    class_1799 head = new class_1799(class_1802.field_8575);
                    player.method_7329(head, false, false);
                }
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            handleHeadRiding(server);
            forceGameRulesOff(server);
            handlePhantomSpawning(server);
            if (dataManager.isEndPortalEnabled()) {
                return;
            }
            tickCounter++;
            if (tickCounter % 100 != 0) {
                return;
            }
            for (class_3222 player : server.method_3760().method_14571()) {
                if (player.method_51469().method_27983() != class_1937.field_25181) {
                    continue;
                }
                player.method_7353(class_2561.method_43470("The End is currently disabled.").method_27692(class_124.field_1061), false);
                class_3218 overworld = server.method_30002();
                class_2338 spawnPos = server.method_74945().method_74897();
                player.method_48105(overworld, spawnPos.method_10263() + 0.5D, spawnPos.method_10264() + 1.0D, spawnPos.method_10260() + 0.5D, java.util.Set.of(), 0.0F, 0.0F, false);
            }
        });

        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            serverInstance = server;
            forceGameRulesOff(server);
        });
    }

    public boolean isEndPortalEnabled() {
        return dataManager.isEndPortalEnabled();
    }

    public void setEndPortalEnabled(boolean enabled) {
        dataManager.setEndPortalEnabled(enabled);
    }

    /**
     * Looks up the LuckPerms "chat-color" meta value from the player's primary
     * group and converts it to a Formatting. Falls back to white if LuckPerms
     * is absent, the player/group can't be resolved, or the meta key isn't set.
     *
     * Set the color on a group with:
     *   /lp group <group> meta set chat-color <minecraft-colour-name>
     * e.g. /lp group default meta set chat-color gray
     */
    private class_124 resolveGroupColor(class_3222 player) {
        if (!LUCKPERMS_LOADED) {
            return class_124.field_1068;
        }
        try {
            LuckPerms lp = LuckPermsProvider.get();
            User user = lp.getUserManager().getUser(player.method_5667());
            if (user == null) {
                return class_124.field_1068;
            }

            Group group = lp.getGroupManager().getGroup(user.getPrimaryGroup());
            if (group == null) {
                return class_124.field_1068;
            }

            String colorName = group.getNodes(NodeType.META).stream()
                    .filter(node -> node.getMetaKey().equals("chat-color"))
                    .map(MetaNode::getMetaValue)
                    .findFirst()
                    .orElse(null);
            if (colorName == null) {
                return class_124.field_1068;
            }

            class_124 formatting = class_124.method_533(colorName.toLowerCase());
            return formatting != null ? formatting : class_124.field_1068;
        } catch (IllegalStateException e) {
            // LuckPerms mod is present but its provider isn't registered yet (e.g. very early startup).
            return class_124.field_1068;
        }
    }

    private void handleHeadRiding(net.minecraft.server.MinecraftServer server) {
        java.util.Iterator<UUID> iterator = headRiders.iterator();
        while (iterator.hasNext()) {
            UUID riderId = iterator.next();
            class_3222 rider = server.method_3760().method_14602(riderId);

            if (rider == null || !rider.method_5805() || !rider.method_5765()) {
                // Rider disconnected, died, or is simply no longer riding — including
                // via vanilla's own built-in sneak-to-dismount, which can run before
                // this tick and beat us to it. Whatever the cause, make sure the
                // target still gets told the passenger is gone.
                notifyTargetOfDismount(server, riderId);
                iterator.remove();
                continue;
            }

            class_1297 vehicle = rider.method_5854();
            if (!(vehicle instanceof class_3222 target)) {
                notifyTargetOfDismount(server, riderId);
                iterator.remove();
                continue;
            }

            if (target.method_5715()) {
                target.method_5772();
                notifyTargetOfDismount(server, riderId);
                iterator.remove();
            }
        }
    }

    /** Who, if anyone, is currently riding {@code targetId}? */
    private UUID findRiderOf(UUID targetId) {
        for (Map.Entry<UUID, UUID> entry : headRiderTargets.entrySet()) {
            if (entry.getValue().equals(targetId)) {
                return entry.getKey();
            }
        }
        return null;
    }

    private void forceGameRulesOff(net.minecraft.server.MinecraftServer server) {
        class_1928 rules = server.method_30002().method_64395();
        forceRuleOff(rules, class_1928.field_19388, server);
        forceRuleOff(rules, class_1928.field_20637, server);
    }

    private void forceRuleOff(class_1928 rules, class_12279 rule, net.minecraft.server.MinecraftServer server) {
        if (Boolean.TRUE.equals(rules.method_76185(rule))) {
            rules.method_76186(rule, Boolean.FALSE, server);
        }
    }

    /**
     * Spawns Phantoms above players standing in The End, on a periodic check that
     * mirrors vanilla's own insomnia condition (DO_INSOMNIA is forced off above, so
     * this is the only place Phantoms come from anymore).
     */
    private void handlePhantomSpawning(net.minecraft.server.MinecraftServer server) {
        phantomTickCounter++;
        if (phantomTickCounter % PHANTOM_CHECK_PERIOD_TICKS != 0) {
            return;
        }

        for (class_3222 player : server.method_3760().method_14571()) {
            class_3218 world = (class_3218) player.method_51469();
            if (world.method_27983() != class_1937.field_25181) {
                continue;
            }
            if (player.method_7325()) {
                continue;
            }
            int timeSinceRest = player.method_14248().method_15025(class_3468.field_15419.method_14956(class_3468.field_15429));
            if (timeSinceRest < PHANTOM_INSOMNIA_TICKS) {
                continue;
            }
            if (phantomRandom.nextInt(PHANTOM_SPAWN_CHANCE_ONE_IN) != 0) {
                continue;
            }

            class_2338 origin = player.method_24515();
            for (int attempt = 0; attempt < 3; attempt++) {
                int dx = phantomRandom.nextInt(PHANTOM_HORIZONTAL_SPREAD * 2 + 1) - PHANTOM_HORIZONTAL_SPREAD;
                int dz = phantomRandom.nextInt(PHANTOM_HORIZONTAL_SPREAD * 2 + 1) - PHANTOM_HORIZONTAL_SPREAD;
                int dy = PHANTOM_MIN_HEIGHT_ABOVE + phantomRandom.nextInt(PHANTOM_HEIGHT_ABOVE_RANGE);
                class_2338 spawnPos = origin.method_10069(dx, dy, dz);
                if (spawnPos.method_10264() >= world.method_31600() - 4) {
                    continue;
                }
                if (!world.method_8320(spawnPos).method_26215()) {
                    continue;
                }

                int count = 1 + phantomRandom.nextInt(2);
                for (int i = 0; i < count; i++) {
                    class_1299.field_6078.method_47821(world, spawnPos, class_3730.field_16459);
                }
                break;
            }
        }
    }

    /**
     * Cleans up tracking state for a rider and, if we know who they were riding,
     * tells that player's client directly that the passenger is gone. Needed for
     * every removal path, not just the ones we trigger ourselves, because a
     * player's own client never receives the normal entity-tracking broadcast
     * about its own passengers.
     */
    private void notifyTargetOfDismount(net.minecraft.server.MinecraftServer server, UUID riderId) {
        UUID targetId = headRiderTargets.remove(riderId);
        if (targetId == null) {
            return;
        }
        class_3222 target = server.method_3760().method_14602(targetId);
        if (target != null) {
            target.field_13987.method_14364(new class_2752(target));
        }
    }

    private void teleportPlayerOutOfTheEnd(class_3222 player) {
        class_2338 spawnPos = serverInstance.method_74945().method_74897();
        player.method_7353(class_2561.method_43470("The End is currently disabled.").method_27692(class_124.field_1061), false);
        player.method_5859(spawnPos.method_10263() + 0.5D, spawnPos.method_10264() + 1.0D, spawnPos.method_10260() + 0.5D);
    }

    private static final class_1304[] ARMOR_AND_OFFHAND_SLOTS = {
        class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166, class_1304.field_6171
    };

    private void dropInventory(class_3222 player) {
        class_1661 inventory = player.method_31548();
        for (class_1799 stack : inventory.method_67533()) {
            if (!stack.method_7960()) {
                player.method_7329(stack.method_7972(), false, false);
            }
        }
        for (class_1304 slot : ARMOR_AND_OFFHAND_SLOTS) {
            class_1799 stack = player.method_6118(slot);
            if (!stack.method_7960()) {
                player.method_7329(stack.method_7972(), false, false);
                player.method_5673(slot, class_1799.field_8037);
            }
        }
        inventory.method_5448();
    }

    private boolean isSelfProjectileKill(class_3222 player, class_1282 damageSource) {
        class_1297 source = damageSource.method_5526();
        if (!(source instanceof net.minecraft.class_1665 projectile)) {
            return false;
        }
        if (projectile.method_24921() instanceof class_1657 owner) {
            return owner.method_5667().equals(player.method_5667());
        }
        return false;
    }
}