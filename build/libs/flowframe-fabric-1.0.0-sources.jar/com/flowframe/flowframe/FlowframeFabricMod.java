package com.flowframe.flowframe;

import java.nio.file.Path;
import java.util.Iterator;
import java.util.Set;
import java.util.UUID;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.group.Group;
import net.luckperms.api.model.user.User;
import net.luckperms.api.node.NodeType;
import net.luckperms.api.node.types.MetaNode;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FlowframeFabricMod implements ModInitializer {
    public static final String MOD_ID = "flowframe";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // Whether the LuckPerms mod is present on this server. Checked once at
    // startup so we never touch the LuckPerms API classes if it isn't loaded.
    private static final boolean LUCKPERMS_LOADED = FabricLoader.getInstance().isModLoaded("luckperms");

    private final DataManager dataManager;
    private final Set<UUID> seenPlayers = new java.util.HashSet<>();
    private final Set<UUID> headRiders = new java.util.HashSet<>();
    private boolean endPortalEnabled;
    private int tickCounter;

    public FlowframeFabricMod() {
        Path configDir = FabricLoader.getInstance().getConfigDir().resolve(MOD_ID);
        this.dataManager = new DataManager(configDir.resolve("keepinv.json"));
        this.endPortalEnabled = false;
    }

    @Override
    public void onInitialize() {
        registerCommands();
        registerEvents();
        LOGGER.info("Flowframe Fabric mod initialized");
    }

    private void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(
                class_2170.method_9247("keepinv")
                    .executes(context -> {
                        class_2168 source = context.getSource();
                        class_3222 player = source.method_44023();
                        if (player == null) {
                            source.method_9226(() -> class_2561.method_43470("This command can only be used by players."), false);
                            return 1;
                        }
                        boolean nowOptedOut = dataManager.toggle(player.method_5667());
                        player.method_7353(class_2561.method_43470("Keep Inventory: " + (nowOptedOut ? "OFF" : "ON")).method_27692(nowOptedOut ? class_124.field_1061 : class_124.field_1060), false);
                        return 1;
                    })
            );

            dispatcher.register(
                class_2170.method_9247("endtoggle")
                    .requires(source -> source.method_9259(2))
                    .executes(context -> {
                        endPortalEnabled = !endPortalEnabled;
                        saveConfig();
                        class_2561 state = endPortalEnabled ? class_2561.method_43470("ENABLED").method_27692(class_124.field_1060) : class_2561.method_43470("DISABLED").method_27692(class_124.field_1061);
                        context.getSource().method_9211().method_3760().method_43514(class_2561.method_43470("End portals are now ").method_10852(state).method_10852(class_2561.method_43470(".")), false);
                        return 1;
                    })
            );
        });
    }

    private void registerEvents() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_3222 player = handler.field_14140;
            if (!seenPlayers.contains(player.method_5667())) {
                seenPlayers.add(player.method_5667());
                server.method_3760().method_43514(class_2561.method_43470(player.method_5477().getString() + " joined the server for the first time! Welcome them!").method_27692(class_124.field_1065), false);
            } else {
                server.method_3760().method_43514(class_2561.method_43470(player.method_5477().getString() + " joined the server").method_27692(class_124.field_1080), false);
            }
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            server.method_3760().method_43514(class_2561.method_43470(handler.field_14140.method_5477().getString() + " left the server").method_27692(class_124.field_1080), false);
        });

        ServerMessageEvents.ALLOW_CHAT_MESSAGE.register((message, sender, params) -> {
            class_124 nameColor = resolveGroupColor(sender);
            class_2561 formatted = class_2561.method_43470(sender.method_5477().getString())
                .method_27692(nameColor)
                .method_10852(class_2561.method_43470(" » ").method_27692(class_124.field_1063))
                .method_10852(class_2561.method_43470(message.method_44862()).method_27692(class_124.field_1068));
            sender.field_13995.method_3760().method_43514(formatted, false);
            return false;
        });

        ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD.register((player, origin, destination) -> {
            if (!endPortalEnabled && destination.method_27983() == class_1937.field_25181) {
                teleportPlayerOutOfTheEnd(player);
            }
        });

        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.method_8608()) {
                return class_1269.field_5811;
            }
            if (!(player instanceof class_3222 rider)) {
                return class_1269.field_5811;
            }
            if (hand != class_1268.field_5808) {
                return class_1269.field_5811;
            }
            if (!rider.method_5998(hand).method_7960() || !rider.method_6079().method_7960()) {
                return class_1269.field_5811;
            }
            if (!(entity instanceof class_3222 target) || target.method_5667().equals(rider.method_5667())) {
                return class_1269.field_5811;
            }
            if (rider.method_5765() || target.method_5782()) {
                return class_1269.field_5811;
            }
            if (rider.method_5873(target, true)) {
                headRiders.add(rider.method_5667());
                return class_1269.field_5812;
            }
            return class_1269.field_5811;
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
            if (entity instanceof class_3222 player) {
                if (dataManager.isOptedOut(player.method_5667())) {
                    dropInventory(player);
                }
                if (isSelfProjectileKill(player, damageSource)) {
                    class_1799 head = new class_1799(class_1802.field_8575);
                    player.method_7329(head, false, false);
                }
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            handleHeadRiding(server);
            if (server.method_3767().method_8355(class_1928.field_19388)) {
                server.method_3767().method_20746(class_1928.field_19388).method_20758(false, server);
            }
            if (endPortalEnabled) {
                return;
            }
            tickCounter++;
            if (tickCounter % 100 != 0) {
                return;
            }
            for (class_3222 player : server.method_3760().method_14571()) {
                if (player.method_37908().method_27983() != class_1937.field_25181) {
                    continue;
                }
                player.method_7353(class_2561.method_43470("The End is currently disabled.").method_27692(class_124.field_1061), false);
                class_3218 overworld = server.method_30002();
                player.method_14251(overworld, overworld.method_43126().method_10263() + 0.5D, overworld.method_43126().method_10264() + 1.0D, overworld.method_43126().method_10260() + 0.5D, 0.0F, 0.0F);
            }
        });

        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            server.method_3767().method_20746(class_1928.field_19388).method_20758(false, server);
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> saveConfig());
    }

    public boolean isEndPortalEnabled() {
        return endPortalEnabled;
    }

    public void setEndPortalEnabled(boolean enabled) {
        endPortalEnabled = enabled;
        saveConfig();
    }

    private void saveConfig() {
        // Persisted state is currently just the toggle flag; the keep-inventory file is handled by DataManager.
    }

    /**
     * Looks up the LuckPerms "chat-color" meta value from the player's primary
     * group and converts it to a Formatting. Falls back to white if LuckPerms
     * is absent, the player/group can't be resolved, or the meta key isn't set.
     *
     * Set the color on a group with:
     *   /lp group <group> meta set chat-color <minecraft-colour-name>
     * e.g. /lp group default meta set chat-color gray
     */
    private class_124 resolveGroupColor(class_3222 player) {
        if (!LUCKPERMS_LOADED) {
            return class_124.field_1068;
        }
        try {
            LuckPerms lp = LuckPermsProvider.get();
            User user = lp.getUserManager().getUser(player.method_5667());
            if (user == null) {
                return class_124.field_1068;
            }

            Group group = lp.getGroupManager().getGroup(user.getPrimaryGroup());
            if (group == null) {
                return class_124.field_1068;
            }

            String colorName = group.getNodes(NodeType.META).stream()
                    .filter(node -> node.getMetaKey().equals("chat-color"))
                    .map(MetaNode::getMetaValue)
                    .findFirst()
                    .orElse(null);
            if (colorName == null) {
                return class_124.field_1068;
            }

            class_124 formatting = class_124.method_533(colorName.toLowerCase());
            return formatting != null ? formatting : class_124.field_1068;
        } catch (IllegalStateException e) {
            // LuckPerms mod is present but its provider isn't registered yet (e.g. very early startup).
            return class_124.field_1068;
        }
    }

    private void handleHeadRiding(net.minecraft.server.MinecraftServer server) {
        Iterator<UUID> iterator = headRiders.iterator();
        while (iterator.hasNext()) {
            UUID riderId = iterator.next();
            class_3222 rider = server.method_3760().method_14602(riderId);
            if (rider == null || !rider.method_5805()) {
                iterator.remove();
                continue;
            }
            if (rider.method_5715()) {
                rider.method_5848();
                iterator.remove();
                continue;
            }
            class_1297 vehicle = rider.method_5854();
            if (!(vehicle instanceof class_3222 target)) {
                iterator.remove();
                continue;
            }
            if (target.method_5715()) {
                target.method_5772();
                iterator.remove();
                continue;
            }
            double mountY = target.method_23318() + target.method_17682() + 0.25D;
            rider.method_5859(target.method_23317(), mountY, target.method_23321());
            rider.method_18800(0.0D, 0.0D, 0.0D);
        }
    }

    private void teleportPlayerOutOfTheEnd(class_3222 player) {
        class_3218 overworld = player.field_13995.method_30002();
        if (overworld == null) {
            return;
        }
        player.method_7353(class_2561.method_43470("The End is currently disabled.").method_27692(class_124.field_1061), false);
        player.method_5859(overworld.method_43126().method_10263() + 0.5D, overworld.method_43126().method_10264() + 1.0D, overworld.method_43126().method_10260() + 0.5D);
    }

    private void dropInventory(class_3222 player) {
        var inventory = player.method_31548();
        for (class_1799 stack : inventory.field_7547) {
            if (!stack.method_7960()) {
                player.method_7329(stack.method_7972(), false, false);
            }
        }
        for (class_1799 stack : inventory.field_7548) {
            if (!stack.method_7960()) {
                player.method_7329(stack.method_7972(), false, false);
            }
        }
        class_1799 offhand = inventory.field_7544.get(0);
        if (!offhand.method_7960()) {
            player.method_7329(offhand.method_7972(), false, false);
        }
        inventory.method_5448();
    }

    private boolean isSelfProjectileKill(class_3222 player, class_1282 damageSource) {
        class_1297 source = damageSource.method_5526();
        if (!(source instanceof net.minecraft.class_1665 projectile)) {
            return false;
        }
        if (projectile.method_24921() instanceof class_1657 owner) {
            return owner.method_5667().equals(player.method_5667());
        }
        return false;
    }
}